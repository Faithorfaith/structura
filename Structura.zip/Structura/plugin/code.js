"use strict";

const FONT_REGULAR  = { family: 'Inter', style: 'Regular' };
const FONT_MEDIUM   = { family: 'Inter', style: 'Medium' };
const FONT_SEMIBOLD = { family: 'Inter', style: 'Semi Bold' };
const FONT_BOLD     = { family: 'Inter', style: 'Bold' };

figma.showUI(__html__, { width: 380, height: 520 });

figma.ui.onmessage = async (msg) => {
  if (msg.type === 'render' && msg.data) {
    try {
      const desktopWidth = Math.max(320, Math.min(3840, Number(msg.width) || 1440));
      const includeMobile = !!msg.mobile;
      await buildLayout(msg.data, desktopWidth, includeMobile);
      figma.notify('Import complete ✓');
    } catch (err) {
      figma.notify('Build failed: ' + (err.message || String(err)), { error: true });
    } finally {
      figma.ui.postMessage({ type: 'done' });
    }
  } else if (msg.type === 'error') {
    figma.notify(msg.message || 'Import failed', { error: true });
    figma.ui.postMessage({ type: 'done' });
  }
};

async function buildLayout(data, desktopWidth, includeMobile) {
  await Promise.all([
    figma.loadFontAsync(FONT_REGULAR),
    figma.loadFontAsync(FONT_MEDIUM),
    figma.loadFontAsync(FONT_SEMIBOLD),
    figma.loadFontAsync(FONT_BOLD),
  ]);

  const frames = [];

  const desktop = buildPage(data, desktopWidth, 'Desktop');
  desktop.x = 0;
  desktop.y = 0;
  figma.currentPage.appendChild(desktop);
  frames.push(desktop);

  if (includeMobile) {
    const mobile = buildPage(data, 390, 'Mobile');
    mobile.x = desktopWidth + 80;
    mobile.y = 0;
    figma.currentPage.appendChild(mobile);
    frames.push(mobile);
  }

  figma.viewport.scrollAndZoomIntoView(frames);
}

function buildPage(data, width, label) {
  const page = figma.createFrame();
  page.name = label + ' — Imported';
  page.layoutMode = 'VERTICAL';
  page.primaryAxisSizingMode = 'AUTO';
  page.counterAxisSizingMode = 'FIXED';
  page.resize(width, 100);
  page.itemSpacing = 0;
  page.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];

  for (const section of data.sections) {
    page.appendChild(buildSection(section, width));
  }

  return page;
}

function buildSection(section, width) {
  const isMobile = width < 500;
  const isTablet = width >= 500 && width < 900;

  const hPad = isMobile ? 20 : isTablet ? 48 : 120;
  const vPad = isMobile ? 48 : isTablet ? 64 : 80;

  const frame = figma.createFrame();
  frame.name = section.type || 'Section';
  frame.layoutMode = 'VERTICAL';
  frame.primaryAxisSizingMode = 'AUTO';
  frame.counterAxisSizingMode = 'FIXED';
  frame.resize(width, 100);
  frame.paddingTop    = vPad;
  frame.paddingBottom = vPad;
  frame.paddingLeft   = hPad;
  frame.paddingRight  = hPad;
  frame.itemSpacing   = isMobile ? 12 : 16;

  const bg = section.backgroundColor ? hexToRgb(section.backgroundColor) : null;
  frame.fills = [{ type: 'SOLID', color: bg || { r: 1, g: 1, b: 1 } }];

  for (const el of section.elements) {
    const node = buildElement(el, isMobile);
    if (!node) continue;
    frame.appendChild(node);
    if (node.type === 'TEXT') {
      node.layoutAlign = 'STRETCH';
    }
  }

  return frame;
}

function buildElement(el, isMobile) {
  if (el.type === 'text')   return buildText(el, isMobile);
  if (el.type === 'button') return buildButton(el, isMobile);
  return null;
}

function buildText(el, isMobile) {
  const node = figma.createText();
  const scale = isMobile ? 0.65 : 1;

  switch (el.style) {
    case 'h1':
      node.fontName   = FONT_BOLD;
      node.fontSize   = Math.round(56 * scale);
      node.lineHeight = { unit: 'PERCENT', value: 110 };
      break;
    case 'h2':
      node.fontName   = FONT_BOLD;
      node.fontSize   = Math.round(40 * scale);
      node.lineHeight = { unit: 'PERCENT', value: 115 };
      break;
    case 'h3':
      node.fontName   = FONT_SEMIBOLD;
      node.fontSize   = Math.round(28 * scale);
      node.lineHeight = { unit: 'PERCENT', value: 120 };
      break;
    default:
      node.fontName   = FONT_REGULAR;
      node.fontSize   = Math.round(16 * scale);
      node.lineHeight = { unit: 'PERCENT', value: 160 };
  }

  node.characters = el.content;

  if (el.color) {
    const c = hexToRgb(el.color);
    if (c) node.fills = [{ type: 'SOLID', color: c }];
  }

  return node;
}

function buildButton(el, isMobile) {
  const frame = figma.createFrame();
  frame.name = 'Button';
  frame.layoutMode = 'HORIZONTAL';
  frame.primaryAxisSizingMode = 'AUTO';
  frame.counterAxisSizingMode = 'AUTO';
  frame.primaryAxisAlignItems = 'CENTER';
  frame.counterAxisAlignItems = 'CENTER';
  frame.paddingTop    = isMobile ? 11 : 14;
  frame.paddingBottom = isMobile ? 11 : 14;
  frame.paddingLeft   = isMobile ? 20 : 28;
  frame.paddingRight  = isMobile ? 20 : 28;
  frame.cornerRadius  = 8;
  frame.fills = [{ type: 'SOLID', color: { r: 0.05, g: 0.05, b: 0.05 } }];

  const label = figma.createText();
  label.fontName   = FONT_SEMIBOLD;
  label.fontSize   = isMobile ? 13 : 15;
  label.characters = el.label;
  label.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
  frame.appendChild(label);

  return frame;
}

function hexToRgb(hex) {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return null;
  return {
    r: parseInt(clean.slice(0, 2), 16) / 255,
    g: parseInt(clean.slice(2, 4), 16) / 255,
    b: parseInt(clean.slice(4, 6), 16) / 255,
  };
}
